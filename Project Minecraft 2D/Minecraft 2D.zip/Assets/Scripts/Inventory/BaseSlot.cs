using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseSlot : DevKacper.Mechanic.Slot
{
    public const int MaxSize = 64;
}
