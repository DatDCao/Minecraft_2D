public enum TileType
{
    Air,
    Dirt,
    DirtGrass,
    Stone,
    TreeLogMid,
    TreeLogBottom,
    TreeLog,
    TreeLeaves,
    Grass,
    Plank,
    CoalOre,
    IronOre,
    GoldOre,
    DiamondOre
}
